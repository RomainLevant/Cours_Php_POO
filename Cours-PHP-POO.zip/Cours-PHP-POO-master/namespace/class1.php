<?php

// Espace de nom : Global
class Foo {
    public function Bar()
    {
        echo "Bar de la classe Foo du namespace global<br>";
    }
}