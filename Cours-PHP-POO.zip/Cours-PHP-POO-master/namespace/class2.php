<?php

// Espace de nom : Nasa
namespace Nasa;

class Foo {
    public function Bar()
    {
        echo "Bar de la classe Foo du namespace Nasa<br>";
    }
}