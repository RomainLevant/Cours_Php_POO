<?php

// Espace de nom : SpaceX
namespace SpaceX;

class Foo {
    public function Bar()
    {
        echo "Bar de la classe Foo du namespace SpaceX<br>";
    }
}