<?php

// Créer une class Vehicule
// Créer une class Voiture
// Créer une class Moto

// Ajouter les methodes: 
// - start
// - stop
// - accelerate
// - decelerate

// Une voiture = 4 roues, 5 portes
// Une moto = 2 roues, 0 porte
// Un vehicule possède un type de motorisation (thermique, electrique) et une couleur

// --- 

// Créer les objets
// Voiture Thermique, rouge
// Voiture Electrique, bleu
// Moto Thermique, rouge
// Moto Electrique, blanche