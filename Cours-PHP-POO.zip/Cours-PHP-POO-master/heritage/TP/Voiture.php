<?php 

class Voiture extends Vehicule
{
    const WHEELS = 4;
    const DOORS = 5;

    public function azert()
    {
    }
    // public function openDoor()
    // {
    //     return "Ouvre la porte";
    // }
}