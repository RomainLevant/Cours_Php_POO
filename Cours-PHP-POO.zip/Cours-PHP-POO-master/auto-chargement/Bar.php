<?php 

class Bar 
{
    public function method()
    {
        echo "Methode de la classe Bar<br>";
    }
}