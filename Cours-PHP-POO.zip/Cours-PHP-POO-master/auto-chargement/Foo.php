<?php 

class Foo 
{
    public function method()
    {
        echo "Methode de la classe Foo<br>";
    }
}